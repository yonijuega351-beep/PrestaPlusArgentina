package ar.com.prestaplus.argentina

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

private val Navy = Color(0xFF071C3C)
private val Blue = Color(0xFF087FE5)
private val Sky = Color(0xFF69D4FF)
private fun ars(n: Double) = NumberFormat.getCurrencyInstance(Locale("es", "AR")).format(n)

data class LoanRequest(val id: Int, val name: String, val amount: Int, val terms: Int, var status: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrestaPlusApp() }
    }
}

@Composable
fun PrestaPlusApp() {
    var page by remember { mutableStateOf("home") }
    var amount by remember { mutableFloatStateOf(200000f) }
    var terms by remember { mutableIntStateOf(12) }
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var requestedName by remember { mutableStateOf("") }
    var applicationNote by remember { mutableStateOf("") }
    var nextId by remember { mutableIntStateOf(4588) }
    val requests = remember {
        mutableStateListOf(
            LoanRequest(4585, "María G. (demo)", 80000, 6, "En revisión"),
            LoanRequest(4586, "Lucas R. (demo)", 150000, 12, "Pendiente"),
            LoanRequest(4587, "Sofía P. (demo)", 250000, 18, "En revisión")
        )
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Sky, background = Color(0xFFF4F8FC))) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = Navy), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("P+  PrestaPlus", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                    Text("A R G E N T I N A", color = Sky, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(12.dp))
                    Text(when(page) {
                        "admin" -> "Panel de administración"
                        "register" -> "Creá tu cuenta"
                        "apply" -> "Solicitar préstamo"
                        "status" -> "Mis solicitudes"
                        "sim" -> "Simulá tu préstamo"
                        else -> "Tu préstamo, más simple."
                    }, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Versión 0.2 · Prototipo de demostración", color = Color(0xFFD6EAFF))
                }
            }

            when (page) {
                "home" -> {
                    Text("Bienvenido", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Explorá las funciones de muestra de PrestaPlus Argentina.")
                    Button(onClick = { page = "sim" }, modifier = Modifier.fillMaxWidth()) { Text("Simular préstamo") }
                    OutlinedButton(onClick = { page = "register" }, modifier = Modifier.fillMaxWidth()) { Text("Crear cuenta (demo)") }
                    OutlinedButton(onClick = { page = "status" }, modifier = Modifier.fillMaxWidth()) { Text("Ver mis solicitudes (demo)") }
                    OutlinedButton(onClick = { page = "admin" }, modifier = Modifier.fillMaxWidth()) { Text("Abrir panel administrativo de muestra") }
                    InfoCard("Rango ilustrativo", "$20.000 a $500.000")
                    InfoCard("Transferencias", "CBU/CVU no conectados en esta versión.")
                }
                "sim" -> {
                    Text("Monto solicitado", fontWeight = FontWeight.SemiBold)
                    Text(ars(amount.toDouble()), style = MaterialTheme.typography.headlineMedium, color = Blue, fontWeight = FontWeight.Bold)
                    Slider(value = amount, onValueChange = { amount = it }, valueRange = 20000f..500000f, steps = 95)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("$20.000"); Text("$500.000") }
                    Text("Cantidad de cuotas: $terms", fontWeight = FontWeight.SemiBold)
                    Slider(value = terms.toFloat(), onValueChange = { terms = ((it / 3).toInt() * 3).coerceIn(3, 36) }, valueRange = 3f..36f, steps = 10)
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Cuota simple estimada, sin intereses ni cargos")
                            Text(ars(amount.toDouble() / terms), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("Costo financiero real: no definido", color = Color.Gray)
                        }
                    }
                    Text("Cálculo ilustrativo; no es una oferta de crédito ni una promesa de aprobación.", style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { page = "apply" }, modifier = Modifier.fillMaxWidth()) { Text("Continuar a solicitud demo") }
                }
                "register" -> {
                    Text("Registro de demostración", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("No uses una contraseña real. Estos datos solo viven en la pantalla durante esta sesión.")
                    OutlinedTextField(fullName, { fullName = it }, label = { Text("Nombre completo (demo)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(email, { email = it }, label = { Text("Correo electrónico (demo)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(password, { password = it }, label = { Text("Contraseña ficticia (demo)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = { page = "apply" }, modifier = Modifier.fillMaxWidth(), enabled = fullName.isNotBlank() && email.contains("@") && password.length >= 4) {
                        Text("Continuar")
                    }
                    Text("No hay cuentas reales, almacenamiento seguro ni verificación de identidad implementados.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
                "apply" -> {
                    Text("Solicitud de prueba", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Completá un nombre para registrar una solicitud ficticia. No ingreses DNI ni datos bancarios.")
                    OutlinedTextField(
                        value = requestedName,
                        onValueChange = { requestedName = it },
                        label = { Text("Nombre o alias de prueba") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Card {
                        Column(Modifier.padding(14.dp)) {
                            Text("Monto simulado: ${ars(amount.toDouble())}", fontWeight = FontWeight.SemiBold)
                            Text("Plazo simulado: $terms cuotas")
                        }
                    }
                    Button(
                        onClick = {
                            requests.add(0, LoanRequest(nextId, requestedName.trim(), amount.toInt(), terms, "Pendiente (demo)"))
                            nextId++
                            applicationNote = "Solicitud de demostración registrada en la memoria de esta sesión."
                            page = "status"
                        },
                        enabled = requestedName.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Enviar solicitud demo") }
                    if (applicationNote.isNotBlank()) Text(applicationNote)
                }
                "status" -> {
                    Text("Solicitudes de muestra", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    if (requests.isEmpty()) Text("Todavía no hay solicitudes de demostración.")
                    requests.forEach { r ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Solicitud #${r.id}", color = Blue, fontWeight = FontWeight.Bold)
                                Text(r.name, fontWeight = FontWeight.SemiBold)
                                Text("${ars(r.amount.toDouble())} · ${r.terms} cuotas")
                                Text("Estado: ${r.status}")
                            }
                        }
                    }
                }
                "admin" -> {
                    Text("Solicitudes registradas en esta sesión", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Este panel es solo una demostración local. No tiene autenticación de administrador y no debe usarse con datos reales.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Text("Total: ${requests.size}", style = MaterialTheme.typography.titleMedium)
                    requests.forEachIndexed { index, r ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("#${r.id} · ${r.name}", fontWeight = FontWeight.Bold)
                                Text("${ars(r.amount.toDouble())} · ${r.terms} cuotas")
                                Text("Estado: ${r.status}")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { requests[index] = r.copy(status = "En revisión (demo)") }) { Text("Revisar") }
                                    Button(onClick = { requests[index] = r.copy(status = "Rechazada (demo)") }) { Text("Rechazar") }
                                }
                                Button(onClick = { requests[index] = r.copy(status = "Aprobada en demo") }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Marcar aprobada (demo)")
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider()
            Text("Navegación", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Inicio" to "home", "Simular" to "sim", "Solicitudes" to "status", "Admin" to "admin").forEach { (label, target) ->
                    OutlinedButton(onClick = { page = target }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Text(label, maxLines = 1)
                    }
                }
            }
            Text("PrestaPlus Argentina · Prototipo no conectado a servicios financieros", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(body)
        }
    }
}
