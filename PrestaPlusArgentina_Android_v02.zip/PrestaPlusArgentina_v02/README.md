# PrestaPlus Argentina — Android v0.2

## Funciones de demostración
- Inicio y navegación.
- Simulador local de $20.000 a $500.000 y de 3 a 36 cuotas.
- Formulario de registro ficticio.
- Formulario de solicitud demo.
- Listado de solicitudes y estados.
- Panel administrativo local con botones para cambiar estados de muestra.

## Abrir
1. Instalá Android Studio en una computadora.
2. Descomprimí el ZIP.
3. Abrí la carpeta `PrestaPlusArgentina_v02` desde Android Studio.
4. Esperá la sincronización de Gradle.
5. Ejecutá en un emulador o dispositivo Android.

## Limitaciones de seguridad y producción
Este proyecto es un prototipo educativo. Los datos de registro no se autentican ni se guardan de forma permanente; las solicitudes solo existen en la memoria de la sesión. El panel administrativo no tiene login ni control de acceso. No ingreses datos reales. No realiza transferencias ni concede préstamos.

Antes de producción, implementar un backend seguro, autenticación real, autorización por roles (cliente/admin), almacenamiento cifrado cuando corresponda, auditoría, protección de datos, prevención de fraude, pruebas de seguridad, contratos y disclosures de costos. Para desembolsos se necesita integración con un proveedor financiero habilitado. No se implementa cobro anticipado para liberar un préstamo.
